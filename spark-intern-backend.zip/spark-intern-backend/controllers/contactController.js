const Contact = require('../models/Contact');
const nodemailer = require('nodemailer');
const mongoose = require('mongoose');

// Form submission controller
const sendContactForm = async (req, res) => {
  const { name, email, phone, college, course, duration } = req.body;

  // Validation
  if (!name || !email || !phone || !college || !course || !duration) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    // Save form data to MongoDB
    const newContact = new Contact({ name, email, phone, college, course, duration });
    await newContact.save();

    // Configure Nodemailer
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS, 
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: 'sparkintern0@gmail.com',
      subject: 'New Enrollment Form Submission',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; background-color: #ffffff;">
          <!-- Logo -->
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="margin: 0; font-size: 24px; color: #007BFF;">✨ Spark Intern ✨</h1>
          </div>
    
          <!-- Main Content -->
          <h2 style="text-align: center; color: #333; font-size: 22px;">
            <strong>New Enrollment Form Submission</strong>
          </h2>
          <div style="margin-top: 20px;">
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">Name:</strong> ${name}
            </p>
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">Phone:</strong> ${phone}
            </p>
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">College:</strong> ${college}
            </p>
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">Email:</strong> ${email}
            </p>
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">Selected Course:</strong> ${course.replace(/-/g, ' ').toUpperCase()}
            </p>
            <p style="color: #555; font-size: 16px;">
              <strong style="color: #007BFF;">Internship Duration:</strong> ${duration.replace(/-/g, ' ').toUpperCase()}
            </p>
          </div>
    
          <!-- Footer -->
          <footer style="margin-top: 30px; text-align: center; font-size: 12px; color: #999;">
            <p>This email is automatically generated. Please do not reply.</p>
            <p>© ${new Date().getFullYear()} Spark Intern. All rights reserved.</p>
          </footer>
        </div>
      `,
    };
    
    
    // Send the email
    await transporter.sendMail(mailOptions);

    res.status(200).json({ message: 'Form submitted successfully!' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error. Please try again later.' });
  }
};

module.exports = { sendContactForm };
