require('dotenv').config();
const express = require('express');
const cors = require('cors'); // Import CORS
const mongoose = require('./config/db'); // MongoDB connection
const contactRoutes = require('./routes/contactRoutes');

const app = express();

// Enable CORS
app.use(cors({
  origin: '*', // Allows requests from all origins (you can restrict this later)
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/contact', contactRoutes);

app.get('/', (req, res) => {
  res.send("Hello Ankush! Welcome to the Contact Form API.");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
